Questao23

#include <stdio.h> // Inclusão de biblioteca

int main() { // Função principal
    int NumA, NumB; // Declaração de variável

    printf("Digite dois números: "); // Impressão de dados
    scanf("%d %d", &NumA, &NumB); // Leitura de dados

    printf("Ordem inversa: %d %d\n", NumB, NumA); // Impressão de dados

    return 0; // Retorno da função
}
