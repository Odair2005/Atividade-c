Questão 34
  
#include <stdio.h> // Inclusão de biblioteca
int main() { // Função principal
 int idade; // Declaração de variável
 printf("Digite a idade: "); // Impressão de dados
 scanf("%d", &idade); // Leitura de dados
 if (idade >= 18) // Estrutura condicional
 printf("Maior de idade"); // Impressão de dados
 else // Alternativa condicional
 printf("Menor de idade"); // Impressão de dados
 return 0; // Retorno da função
}
