Questão 36
  
#include <stdio.h> // Inclusão de biblioteca
int main() { // Função principal
 int numero; // Declaração de variável
 printf("Digite um número: "); // Impressão de dados
 scanf("%d", &numero); // Leitura de dados
 if (numero > 0) // Estrutura condicional
 printf("Positivo"); // Impressão de dados
 else if (numero < 0) // Alternativa condicional
 printf("Negativo"); // Impressão de dados
 else // Alternativa condicional
 printf("Zero"); // Impressão de dados
 return 0; // Retorno da função
}
