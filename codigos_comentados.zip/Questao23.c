Questão 29
  
#include <stdio.h> // Inclusão de biblioteca
int main() { // Função principal
 int numero; // Declaração de variável
 printf("Digite um número: "); // Impressão de dados
 scanf("%d", &numero); // Leitura de dados
 if (numero > 100) // Estrutura condicional
 printf("%d", numero); // Impressão de dados
 else // Alternativa condicional
 printf("0"); // Impressão de dados
 return 0; // Retorno da função
}
