Questão 38
  
#include <stdio.h> // Inclusão de biblioteca
int main() { // Função principal
 int numero; // Declaração de variável
 printf("Digite um número: "); // Impressão de dados
 scanf("%d", &numero); // Leitura de dados
 if (numero % 5 == 0) // Estrutura condicional
 printf("Múltiplo de 5"); // Impressão de dados
 else // Alternativa condicional
 printf("Não é múltiplo de 5"); // Impressão de dados
 return 0; // Retorno da função
}
