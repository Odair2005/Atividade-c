Questão 81
  
#include <stdio.h> // Inclusão de biblioteca

int main() { // Função principal
    int i; // Declaração de variável
    for(i = 100; i >= 1; i--) { // Estrutura de repetição
        printf("%d ", i); // Impressão de dados
    }
    printf("\n"); // Impressão de dados
    return 0; // Retorno da função
}
