Questão 37
  
#include <stdio.h> // Inclusão de biblioteca
int main() { // Função principal
 int numero; // Declaração de variável
 printf("Digite um número: "); // Impressão de dados
 scanf("%d", &numero); // Leitura de dados
 printf("Antecessor: %d", numero - 1); // Impressão de dados
 return 0; // Retorno da função
}
